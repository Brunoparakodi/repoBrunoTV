# <a href="repository.NAME.zip">DOWNLOADDO REPOSITÓRIO</a>

Instruções para a adição no gestor:


<p align="left">
  <ul>
    <li>Ir para o Kodi gestor de ficheiros.</li>
    <li>Clicar em "Adicionar fonte"</li>
    <li>O endereço para a fonte é <code>https://LINK_DA_FONTE</code> (Dar o nome de "repository.NAME").</li>
    <li>Ir para "Addons"</li>
    <li>Em Addons, instalar de um ficheiro zip. Quando perguntar pela localização, selecionar "repository.NAME", e instalar <a href="repository.NAME.zip">repository.NAME.zip</a>.</li>
    -
    <li>Repositório Instalado!</li>
    
</ul>

                                      
                                       

</p>

